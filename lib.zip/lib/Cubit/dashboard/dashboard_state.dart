class DashboardState {}

class DashboardInitial extends DashboardState{}

class DashboardLoading extends DashboardState{}

class DashboardSuccess extends DashboardState{}

class DashboardFailure extends DashboardState{}