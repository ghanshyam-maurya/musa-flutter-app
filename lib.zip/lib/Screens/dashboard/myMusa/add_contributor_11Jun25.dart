import 'package:musa_app/Cubit/dashboard/Contributor/add_contributor_cubit.dart';
import 'package:musa_app/Cubit/dashboard/Contributor/add_contributor_state.dart';
import 'package:musa_app/Utility/musa_widgets.dart';
import 'package:musa_app/Utility/packages.dart';

class AddContributor extends StatefulWidget {
  final List<String> initialSelectedContributors; // Receive selected users
  final bool? isComeFromProfile;
  final String? musaId;
  final Function(int)? contributorAddCount;

  const AddContributor(
      {super.key,
      required this.initialSelectedContributors,
      this.isComeFromProfile,
      this.musaId,
      this.contributorAddCount});

  @override
  State<AddContributor> createState() => _AddContributorState();
}

class _AddContributorState extends State<AddContributor> {
  AddContributorCubit cubit = AddContributorCubit();

  late Map<String, String> _selectedContributors;
  bool isComeFromProfile = false;

  TextEditingController searchController = TextEditingController();
  ValueNotifier<String> searchQuery = ValueNotifier<String>("");

  @override
  void initState() {
    super.initState();
    _selectedContributors = {};
    isComeFromProfile =
        widget.isComeFromProfile != null && widget.isComeFromProfile!;

    if (widget.isComeFromProfile != null && widget.isComeFromProfile!) {
      cubit.selectedContributors = {};
      cubit.getContributorUsersListWithStatus(widget.musaId);
    } else {
      cubit.getContributorUsersList();
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      cubit.init();
      cubit.stream.listen((state) {
        for (var id in widget.initialSelectedContributors) {
          var user = cubit.contributorList.firstWhere((u) => u.id == id);
          cubit.selectedContributors[id] = "${user.firstName} ${user.lastName}";
        }
        setState(() {});
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<AddContributorCubit, AddContributorState>(
        bloc: cubit,
        listener: (context, state) {
          if (state is AddContributorError) {
            MusaPopup.popUpDialouge(
                context: context,
                onPressed: () => context.pop(true),
                buttonText: 'Okay',
                title: 'Error',
                description: state.errorMessage);
          }
          if (state is AddedContributorsInMusa) {
            widget.contributorAddCount!(
                cubit.selectedContributors.length.toInt());
            Navigator.pop(context);
          }
        },
        builder: (context, state) {
          return Stack(
            children: [
              buildAddContributorSection(),
              state is AddContributorLoading
                  ? MusaWidgets.loader(context: context, isForFullHeight: true)
                  : Container()
            ],
          );
        },
      ),
    );
  }

  buildAddContributorSection() {
    return Column(
      children: [
        AppBarMusa1(
          title: "Add Contributor",
          appBarBtn: () {
            if (widget.isComeFromProfile != null && widget.isComeFromProfile!) {
              cubit.addContributorsInMyMusa(widget.musaId);
            } else {
              Navigator.pop(context, cubit.selectedContributors);
            }
          },
          appBarBtnText: 'Done',
        ),
        buildContributorUserSearch(),
        SizedBox(height: 10),
        buildContributorUserList(),
      ],
    );
  }

  Widget buildContributorUserList() {
    return Expanded(
      child: ValueListenableBuilder<String>(
        valueListenable: searchQuery,
        builder: (context, query, _) {
          final filteredContributors =
              cubit.contributorList.where((contributor) {
            bool isAlreadyContributor = contributor.contributeStatus == 1;
            String userName =
                "${contributor.firstName ?? ''} ${contributor.lastName ?? ''}"
                    .trim();
            return userName.isNotEmpty &&
                !isAlreadyContributor &&
                userName.toLowerCase().contains(query);
          }).toList();

          return filteredContributors.isEmpty
              ? Center(child: Text("No contributors available"))
              : ListView.separated(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 3),
                  itemCount: filteredContributors.length,
                  separatorBuilder: (_, index) => Divider(),
                  itemBuilder: (_, index) {
                    var contributor = filteredContributors[index];
                    var user = contributor.id;
                    bool isSelected = _selectedContributors.containsKey(user);

                    return Row(
                      children: [
                        CircleAvatar(
                          radius: 20,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(60),
                            child: FadeInImage(
                              fit: BoxFit.cover,
                              width: 120,
                              height: 120,
                              image: NetworkImage(contributor.photo ?? ""),
                              placeholder: NetworkImage(Assets.emptyProfile),
                              imageErrorBuilder: (context, error, stackTrace) {
                                return Image.network(Assets.emptyProfile,
                                    fit: BoxFit.cover);
                              },
                            ),
                          ),
                        ),
                        SizedBox(width: 10),
                        Text(
                          "${contributor.firstName} ${contributor.lastName}",
                          style: AppTextStyle.semiTextStyle(
                              color: AppColor.black, size: 12),
                        ),
                        Spacer(),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              // if (!isComeFromProfile) {
                              if (isSelected) {
                                _selectedContributors.remove(user);
                                cubit.selectedContributors.remove(user);
                              } else {
                                _selectedContributors[user.toString()] =
                                    "${contributor.firstName} ${contributor.lastName}";
                                cubit.selectedContributors[user.toString()] =
                                    "${contributor.firstName} ${contributor.lastName}";
                              }
                              // }
                            });
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: isSelected
                                  ? Colors.red
                                  : AppColor.primaryColor,
                            ),
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 8),
                            child: Row(
                              children: [
                                Icon(
                                  isSelected ? Icons.remove : Icons.group_add,
                                  color: Colors.white,
                                  size: 12,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  isSelected ? "Remove" : "Add Contributor",
                                  style: AppTextStyle.semiMediumTextStyle(
                                    color: Colors.white,
                                    size: 10,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                );
        },
      ),
    );
  }

  Widget buildContributorUserSearch() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextField(
        controller: searchController,
        onChanged: (value) {
          searchQuery.value = value.trim().toLowerCase(); // Update search query
        },
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.search, color: AppColor.grey),
          hintText: 'Search contributors...',
          filled: true,
          fillColor: Colors.grey.shade300,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.r),
            borderSide: BorderSide.none,
          ),
          contentPadding:
              EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.h),
        ),
      ),
    );
  }
}
