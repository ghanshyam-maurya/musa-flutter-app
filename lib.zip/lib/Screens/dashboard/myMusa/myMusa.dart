import 'package:flutter/material.dart';

class Mymusa extends StatefulWidget {
  const Mymusa({super.key});

  @override
  State<Mymusa> createState() => _MymusaState();
}

class _MymusaState extends State<Mymusa> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("MyMusa"),
    );
  }
}